// script.js - Lógica Lexicon Studio Web

class PalabrasEngine {
    constructor() {
        const SUPABASE_URL = 'https://aws-1-eu-west-1.pooler.supabase.com';
        const SUPABASE_KEY = 'postgres.kkfyyedgtiqfkxqniuxg'; // Tu user
        this.supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
            auth: {
                autoRefreshToken: false,
                persistSession: false
            }
        });
        this.dbMode = 'nube';
    }

    listarRapido(filtro = '') {
        const normalized = filtro.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        return this.words.filter(w => 
            w.termino.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').includes(normalized)
        ).slice(0, 100);
    }

    obtenerPalabraAzar() {
        if (this.words.length === 0) return null;
        const rand = this.words[Math.floor(Math.random() * this.words.length)];
        return {termino: rand.termino.toUpperCase(), definicion: rand.definicion};
    }

    contarTotal() {
        return this.words.length;
    }

    insertar(termino, definicion, tipo) {
        const id = Date.now();
        this.words.unshift({id, termino: termino.toLowerCase(), definicion, tipo});
        this.save();
        return 'OK';
    }

    actualizar(id, termino, definicion, tipo) {
        const word = this.words.find(w => w.id == id);
        if (word) {
            word.termino = termino.toLowerCase();
            word.definicion = definicion;
            word.tipo = tipo;
            this.save();
            return 'OK';
        }
        return 'Error';
    }

    eliminar(id) {
        this.words = this.words.filter(w => w.id != id);
        this.save();
        return 'OK';
    }

    getCategorias() {
        return {
            'sust': 'Sustantivo',
            'adj': 'Adjetivo',
            'verb': 'Verbo',
            'adv': 'Adverbio',
            'pron': 'Pronombre',
            'prep': 'Preposición',
            'conj': 'Conjunción',
            'inter': 'Interjección'
        };
    }
}

// Engine global
const engine = new PalabrasEngine();

// UI Gestión
let selectedId = null;
let debounceTimer;

document.addEventListener('DOMContentLoaded', () => {
    // Stats
    updateStats();

    // Nav
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            switchSection(e.target.id.replace('btn-', ''));
        });
    });

    // Búsqueda
    document.getElementById('busqueda').addEventListener('input', debounceSearch);

    // Modal
    document.getElementById('btn-save').addEventListener('click', saveWord);
    document.getElementById('btn-cancel').addEventListener('click', closeModal);
    document.getElementById('btn-delete').addEventListener('click', deleteWord);

    updateLista();
    switchSection('dashboard');
});

function debounceSearch() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(updateLista, 300);
}

function updateLista() {
    const filtro = document.getElementById('busqueda').value;
    const lista = document.getElementById('lista-palabras');
    const palabras = engine.listarRapido(filtro);

    lista.innerHTML = '';
    palabras.forEach(p => {
        const card = document.createElement('div');
        card.className = 'palabra-card';
        card.onclick = () => editWord(p);
        card.innerHTML = `
            <div class="palabra-titulo">${p.termino.toUpperCase()}</div>
            <span class="palabra-cat">${engine.getCategorias()[p.tipo] || p.tipo}</span>
            <div class="palabra-prev">${p.definicion.substring(0, 100)}...</div>
            <div style="margin-top:10px">
                <a href="https://dle.rae.es/${p.termino}" target="_blank" class="rae-link">RAE</a>
                <a href="https://es.wiktionary.org/wiki/${p.termino}" target="_blank" class="wiki-link">Wiki</a>
            </div>
        `;
        lista.appendChild(card);
    });
}

function editWord(p) {
    selectedId = p.id;
    document.getElementById('modal-title').textContent = 'Editar: ' + p.termino;
    document.getElementById('input-word').value = p.termino;
    document.getElementById('input-cat').value = p.tipo;
    document.getElementById('input-def').value = p.definicion;
    document.getElementById('btn-delete').style.display = 'inline-block';
    document.getElementById('modal-edit').classList.add('active');
}

function closeModal() {
    document.getElementById('modal-edit').classList.remove('active');
    selectedId = null;
    document.getElementById('modal-title').textContent = 'Nueva Palabra';
    document.getElementById('input-word').value = '';
    document.getElementById('input-cat').value = 'sust';
    document.getElementById('input-def').value = '';
    document.getElementById('btn-delete').style.display = 'none';
}

function saveWord() {
    const termino = document.getElementById('input-word').value.trim();
    const tipo = document.getElementById('input-cat').value;
    const definicion = document.getElementById('input-def').value.trim();

    if (!termino) return alert('Palabra requerida');

    if (selectedId) {
        engine.actualizar(selectedId, termino, definicion, tipo);
    } else {
        engine.insertar(termino, definicion, tipo);
    }

    updateLista();
    updateStats();
    closeModal();
}

function deleteWord() {
    if (confirm('¿Borrar palabra?')) {
        engine.eliminar(selectedId);
        updateLista();
        updateStats();
        closeModal();
    }
}

// Juego Ahorcado
let game = null;

function initJuego() {
    game = {
        palabra: '',
        pista: '',
        intentos: 6,
        adivinadas: new Set(),
        falladas: new Set(),
        gameOver: false,
        canvas: document.getElementById('canvas-ahorcado'),
        ctx: null
    };
    game.ctx = game.canvas.getContext('2d');
    resizeCanvas();
    const wordData = engine.obtenerPalabraAzar();
    if (wordData) {
        game.palabra = wordData.termino;
        game.pista = wordData.definicion;
    } else {
        game.palabra = 'CASA';
        game.pista = 'Lugar para vivir';
    }
    document.getElementById('game-hint').textContent = 'Pista: ' + game.pista;
    createTeclado();
    updatePantallaJuego();
    window.addEventListener('resize', resizeCanvas);
}

function resizeCanvas() {
    const rect = game.canvas.getBoundingClientRect();
    game.canvas.width = rect.width;
    game.canvas.height = rect.height * 1.4; // Aspect ratio
    game.ctx.scale(1,1);
    updatePantallaJuego();
}

function createTeclado() {
    const alf = 'ABCDEFGHIJKLMNÑOPQRSTUVWXYZ';
    const teclado = document.getElementById('teclado');
    teclado.innerHTML = '';
    for (let letra of alf) {
        const btn = document.createElement('button');
        btn.textContent = letra;
        btn.className = 'tecla';
        btn.onclick = () => probarLetra(letra);
        teclado.appendChild(btn);
    }
}

function probarLetra(letra) {
    if (game.gameOver || game.adivinadas.has(letra) || game.falladas.has(letra)) return;

    if (game.palabra.includes(letra)) {
        game.adivinadas.add(letra);
    } else {
        game.falladas.add(letra);
        game.intentos--;
    }

    document.querySelectorAll('.tecla').forEach(b => {
        if (b.textContent === letra) b.disabled = true;
    });

    updatePantallaJuego();
}

function updatePantallaJuego() {
    const ctx = game.ctx;
    ctx.clearRect(0, 0, game.canvas.width, game.canvas.height);

    const w = game.canvas.width;
    const h = game.canvas.height;
    const scaleX = w / 280;
    const scaleY = h / 420;

    ctx.save();
    ctx.scale(scaleX, scaleY);

    // Horca base
    ctx.strokeStyle = '#8B4513';
    ctx.lineWidth = 8;
    ctx.lineCap = 'round';

    // Postes
    ctx.beginPath();
    ctx.moveTo(50, 50);
    ctx.lineTo(50, 100);
    ctx.lineTo(140, 100);
    ctx.lineTo(140, 130);
    ctx.lineTo(110, 130);
    ctx.lineTo(110, 350);
    ctx.stroke();

    // Cuña
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(80, 150);
    ctx.lineTo(110, 130);
    ctx.stroke();

    const errores = 6 - game.intentos;
    if (errores >= 1) {
        // Cabeza
        ctx.lineWidth = 4;
        ctx.fillStyle = '#FDBCB4';
        ctx.strokeStyle = 'black';
        ctx.beginPath();
        ctx.arc(110, 150, 15, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
    }
    if (errores >= 2) {
        // Tronco
        ctx.lineWidth = 8;
        ctx.strokeStyle = 'black';
        ctx.beginPath();
        ctx.moveTo(110, 165);
        ctx.lineTo(110, 240);
        ctx.stroke();
    }
    if (errores >= 3) {
        ctx.lineWidth = 8;
        ctx.beginPath();
        ctx.moveTo(110, 185);
        ctx.lineTo(135, 205);
        ctx.stroke();
    }
    if (errores >= 4) {
        ctx.beginPath();
        ctx.moveTo(110, 185);
        ctx.lineTo(85, 205);
        ctx.stroke();
    }
    if (errores >= 5) {
        ctx.beginPath();
        ctx.moveTo(110, 240);
        ctx.lineTo(95, 290);
        ctx.stroke();
    }
    if (errores >= 6) {
        ctx.beginPath();
        ctx.moveTo(110, 240);
        ctx.lineTo(125, 290);
        ctx.stroke();
    }

    ctx.restore();

    // Palabra
    let mostrada = '';
    let ganado = true;
    for (let char of game.palabra) {
        if (game.adivinadas.has(char) || !char.match(/[A-ZÑ]/)) {
            mostrada += char + ' ';
        } else {
            mostrada += '_ ';
            ganado = false;
        }
    }
    document.getElementById('palabra-mostrada').textContent = mostrada.trim();
    document.getElementById('intentos-restantes').textContent = `Intentos: ${game.intentos}`;

    if (ganado && !game.gameOver) {
        mostrarVictoria();
    } else if (game.intentos === 0 && !game.gameOver) {
        mostrarDerrota();
    }
}

function mostrarVictoria() {
    game.gameOver = true;
    document.getElementById('game-win').classList.add('active');
}

function mostrarDerrota() {
    game.gameOver = true;
    document.getElementById('palabra-final').textContent = game.palabra;
    document.getElementById('game-lose').classList.add('active');
}

function newGame() {
    document.getElementById('game-win').classList.remove('active');
    document.getElementById('game-lose').classList.remove('active');
    initJuego();
}

// Otras funciones UI
function updateStats() {
    document.getElementById('stats-total').textContent = `Total palabras: ${engine.contarTotal()}`;
}

function switchSection(section) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(section).classList.add('active');
    document.getElementById('btn-' + section).classList.add('active');

    if (section === 'juego') {
        if (!game) initJuego();
    }
}

document.getElementById('toggle-db').onclick = () => {
    engine.dbMode = engine.dbMode === 'local' ? 'nube' : 'local';
    document.getElementById('toggle-db').textContent = `DB: ${engine.dbMode.toUpperCase()}`;
    // Simula recarga
    updateLista();
};

// Cargar select categorías
const catSelect = document.getElementById('input-cat');
Object.entries(engine.getCategorias()).forEach(([key, val]) => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = val;
    catSelect.appendChild(opt);
});
